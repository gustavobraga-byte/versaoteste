"""
__version__.py — Fonte única de versão do PesquisAI v0.4.2.2.

Este repositório contém o **PesquisAI release v0.4.2.2** + sandbox pessoal:

Estrutura do repositório:
  /                       # PesquisAI release v0.4.2.2 (raiz)
  ├── agents/             # AGENTS.md multilíngues (4 idiomas)
  ├── docs/               # Documentação (CHANGELOG, PATCH, etc.)
  ├── grant_finder/       # Skill de busca de fomento
  ├── i18n/               # Módulo multilíngue
  ├── pesquisai/          # Módulo PesquisAI (v0.4.2.2)
  │   ├── __version__.py  # ⭐ Fonte única da versão (v0.4.2.2)
  │   ├── launch_app.py
  │   ├── launch_app_responsive.py
  │   └── launch_app_responsive_v041.py
  ├── releases/v0.4.0/    # Release isolada completa
  ├── sandbox/            # 🏖️ Arquivos não-PesquisAI
  ├── sessions/           # Logs de sessão
  └── skills/             # Skills adicionais (grant-finder, meta-search-br)

Compatível com o PesquisAI principal (v0.2.1+).

═════════════════════════════════════════════════════════════════════════
Histórico de versões:
═══════════════════════════════════════════════════════════════════════
  v0.7.11 — 06/11/2026: 🛡 VPN da UFV no Colab (OpenVPN em namespace isolado)
    • PEDIDO DO AUTOR: "o servidor do Colab conecte via internet via VPN da UFV"
      e, depois, "vai abrir uma tela logo quando iniciar para escolher se ele é
      aluno da UFV ou não; se clicar em aluno, aparece a interface solicitando
      o CPF e a senha, que são as credenciais para entrar no VPN".
    • DIAGNÓSTICO: o Colab não tem `/dev/net/tun` nem `CAP_NET_ADMIN`
      (`CapEff=00000000a82c25fb`); `ip tuntap add` falha. `mknod` funciona e
      `unshare -Urn` + `slirp4netns` resolvem.
    • ARQUITETURA: OpenVPN dentro de user+net namespace + slirp4netns +
      proxy SOCKS5 (stdlib) publicado em `127.0.0.1:1081` via `add_hostfwd`.
      O tráfego só entra na VPN quando o processo usa o proxy — não é túnel
      transparente (impossível sem NET_ADMIN no namespace raiz).
    • UFV: perfil oficial `https://vpn.ufvnet.ufv.br/configs/UFV-linux.ovpn`
      (OpenVPN, `vpn.ufvnet.ufv.br:1195/UDP`, CPF + senha, split tunnel,
      1 dispositivo por CPF).
    • TELA INICIAL: "Você é aluno(a) da UFV?" (Sim → painel CPF/senha;
      Não → segue sem VPN). A escolha fica em `prefs.json` + localStorage.
    • PAINEL: status ao vivo, avisos (1 dispositivo, split tunnel, senha),
      conectar/desconectar, testar acesso interno (`sistemas.ufv.br`),
      baixar/colar perfil .ovpn, esquecer credenciais.
    • SEGURANÇA: senha nunca em log/linha de comando; arquivo `auth` 0600
      apagado ao desconectar; "lembrar" grava CPF/senha cifrados no
      `keys_store.json` com prefixo `vpn_ufv_` (filtrado de `/api/apikey`).
    • API: `GET /api/vpn`; `POST /api/vpn/{connect,disconnect,profile,test,
      forget,answer}`.
    • CLI: `python -m pesquisai.vpn status|connect|disconnect|profile|test`.
    • TESTES: `tests/test_v0711_vpn.py` (15 testes offline; o teste real
      depende das credenciais do usuário).
  v0.7.10 — 05/11/2026: 🧭 Onboarding de primeiro uso (provedor + chave)
    • REGRA DO AUTOR: "um novo user, quero que ele use a apikey dele, mas de
      modo simples"; a tela aparece no primeiro uso e também para quem já usa
      o UFVAI mas ficou sem chave.
    • TELAS: depois dos Termos → "Para usar o UFVAI você precisa de um
      provedor de IA" com duas opções (já tenho / não tenho ou não sei).
      "Não tenho" abre as opções: Google Gemini (RECOMENDADO), NVIDIA,
      OpenRouter e OpenCode Go (PAGA); cada uma leva ao tutorial do provedor,
      com link e reprodução da tela, e ao campo de colar a chave.
    • GOOGLE: link para aistudio.google.com/api-keys, instrução de clicar em
      Copiar e voltar; a chave é salva como GOOGLE_GENERATIVE_AI_API_KEY.
    • MODELO PADRÃO: com chave do Google, o padrão passa a ser
      `google/gemini-flash-lite-latest` (constante `GOOGLE_DEFAULT_MODEL`, ajustável
      por UFVAI_GOOGLE_MODEL) e continua valendo nos próximos usos.
    • SEM CHAVE = TELA: a condição é objetiva (`needs_onboarding`), sem flag
      de "já viu" — quem perdeu a chave volta a ver o guia.
    • API: `GET /api/onboarding` e `POST /api/onboarding/key` (grava cifrado,
      injeta no serviço, define o modelo e reinicia o terminal).
    • Módulo puro `pesquisai/onboarding.py` + testes em
      `tests/test_v0710_onboarding.py`.
  v0.7.9 — 04/11/2026: 🔑 Chaves de API e free tier para novos usuários
    • Instruções de chave gratuita (OpenRouter, NVIDIA) aparecem quando não há chave salva
    • Seletor de modelos gratuitos (OpenRouter :free e NVIDIA) + "modelo padrão"
    • Link para opção paga (OpenCode Go)
    • Aviso ao abrir: chaves de API são responsabilidade do usuário, sem vínculo com a plataforma
    • Botão ⚙ Autosave: intervalo (1–60 min) e escolha de conversas
  v0.7.8 — 29/10/2026: 🔑 Chaves de API do Drive chegavam ao shell, não ao SERVIÇO
            • RELATO DO AUTOR: "o UFVAI não está carregando as chaves de API
              que estão no Drive. Aconteceu depois que o opencode atualizou
              para a v2.2".
            • CAUSA [DADO CONFIRMADO no runtime]: `run_fast.run()` chama
              `ensure_service_project_dir()` ANTES de `start_wrapper_server()`,
              que é quem chamava `load_keys_from_drive()`. O
              `opencode serve --service` nascia sem NENHUMA variável de chave
              (medido: `/proc/<pid>/environ` com 0 das 5 variáveis, enquanto o
              shell tinha as 5). Até o motor 2.1 a TUI resolvia provedores com
              o próprio ambiente; na v2.2 o catálogo é resolvido DENTRO do
              serviço — por isso o sintoma só apareceu agora.
              Prova: `opencode models` (via serviço) → opencode, opencode-go;
              `opencode models --standalone` (env do shell) → + openrouter,
              google e nvidia.
            • CORREÇÃO (1): `ensure_service_project_dir(..., backup_dir=)`
              decifra o `keys_store.json`, injeta as variáveis no `env` do
              Popen do serviço E no `os.environ` do boot.
            • CORREÇÃO (2) — auto-cura: serviço já no diretório certo mas sem
              as chaves é reiniciado (`service_missing_key_envs`), então um
              boot antigo não deixa o motor "cego" para sempre.
            • CORREÇÃO (3): ao salvar/remover chave pela interface, o serviço
              volta JÁ com as chaves novas (`_start_opencode_service_with_keys`)
              antes do reinício do terminal.
            • DIAGNÓSTICO: `scripts/diag_keys_v22.py` (store × processo ×
              serviço × `opencode models`), sem imprimir segredo; códigos de
              saída 0/1/2/3.
            • Testes: `tests/test_v078_service_keys.py` (14 testes).
  v0.7.7 — 27/10/2026: 🔒 Drive Guard — "My Drive" só dentro de PesquisAI
            • REGRA DO AUTOR: "não deixe acessar a pasta My Drive exceto a
              subpasta PesquisAI e todas as suas subpastas — mesmo estando em
              auto".
            • Plugin do servidor UFVAI V2 (`pesquisai/plugins/drive_guard/`)
              instalado em `<config>/plugins/ufvai-drive-guard/` no boot
              (`ensure_drive_guard()`, fail-open).
            • TRÊS CAMADAS: (1) regras `permissions` no `opencode.json` —
              `deny` da raiz vigiada seguido de `allow` de PesquisAI (regra
              `deny` é final: `--auto` não a converte em aprovação);
              (2) hook `permission.evaluate`; (3) hook `tool.execute.before`,
              que lança erro antes de qualquer acesso ao disco.
            • Raiz vigiada `/content/drive` (fecha enumeração de "My Drive");
              liberado `/content/drive/My Drive/PesquisAI` e subpastas.
            • `..`, `file://`, `~` e comandos de shell (sem aspas, com aspas,
              `-c "open(...)"`) são resolvidos antes da decisão; referência
              ofuscada cai em falha fechada. No Colab, `MyDrive` e "My Drive"
              são o MESMO diretório (mesmo inode): a comparação normaliza os
              dois nomes, então `MyDrive/PesquisAI` continua acessível e
              `MyDrive/<qualquer outra coisa>` continua bloqueado.
            • Auditoria em `~/.local/state/ufvai/drive-guard.log`.
            • Testes: `tests/js/test_drive_guard.mjs` (34 verificações, Node
              puro) e `tests/test_drive_guard.py` (20 testes).
  v0.7.6 — 24/10/2026: 🏷️ Rebrand do agente: "opencode" → "ufvai" (identidade
            completa, no estilo Flint)
            • DOCUMENTOS DO AGENTE: AGENTS.md + agents/AGENTS.{pt,en,es,fr,zh}.md
              + novo agents/UFVAI.md — todas as ocorrências de opencode/OpenCode
              viraram ufvai/UFVAI (caminhos ~/.config/ufvai/, ufvai.json,
              ~/.local/share/ufvai/, comando `ufvai auth export`); §0.1 rebatizada
              de "Motor UFVAI V2".
            • ALIASING DO MOTOR: scripts/ufvai-alias.sh cria symlinks
              (~/.config/ufvai, ~/.local/share/ufvai, ufvai.json) e o comando
              `ufvai` (wrapper POSIX com OPENCODE_CONFIG_DIR/OPENCODE_CONFIG) —
              o runtime físico continua sendo o motor original; nada renomeado
              em execução (banco SQLite/crédenciais intactos).
            • PRESERVADO: código (pesquisai/opencode_*.py), install-offline.sh,
              Dockerfile, histórico do CHANGELOG e citações funcionais do
              gateway (OpenCode Zen/Go) — o rebrand é de IDENTIDADE.
  v0.7.0 — 21/10/2026: 🏷️ Marca UFVAI na tela de NOVA SESSÃO + 4 correções
            de interface
            • LOGO: a arte de blocos "opencode" da tela de nova sessão foi
              redesenhada como "UFVAI" (5 letras, mesma grade de 4 linhas x 19
              células por metade, mesmo two-tone: esquerda muted / direita base).
              O logo compacto (tela < 22 colunas) virou "U".
            • SUGESTÕES DO PROMPT: o placeholder "Ask anything… \"<sugestão>\""
              passa a sugerir uso do UFVAI e uso agentico:
                "Monte um plano de pesquisa" · "Qual a base de dados da minha
                pesquisa?" · "Revise o artigo."
            • MECANISMO: `pesquisai/tui_branding.py` faz patch do binário do
              motor com substituições de MESMO COMPRIMENTO DE BYTE (o bytecode
              do Bun referencia literais por offset — mudar o tamanho
              corromperia o binário), backup em `<binário>.orig-ufvai-brand`,
              restauração no boot, fail-open e desligável por
              `UFVAI_TUI_BRANDING=0`. Só literais de EXIBIÇÃO são tocados.
              Isto revoga a decisão de 18/10 ("não patchar o binário").
            • CHINÊS TAMBÉM TROCA O TERMINAL: `_UI_TO_TUI_LOCALE` não tinha a
              entrada `zh_CN` → a troca de idioma na UI web aceitava o chinês
              mas o terminal continuava no idioma anterior (retorno silencioso).
            • TEMA CLARO NO MANUAL E NAS DIRETRIZES: o wrapper carregava só
              `github-markdown-dark.min.css` → o markdown do MANUAL.md e do
              AGENTS.md saía escuro no tema claro. Paleta remapeada para as
              variáveis do tema claro (sem depender do CDN — funciona offline).
            • SANDUÍCHE DO RESPONSIVO: o item "Idioma" foi REMOVIDO do drawer —
              o seletor `.lang-btn` da topbar continua visível no mobile.
            • SEGUNDO CÉREBRO NO RESPONSIVO: o container do split da Memória era
              um div anônimo (sem id) → no mobile o pai ficava em flex ROW, a
              sidebar com width:100% tomava a linha inteira e o pane da NOTA
              saía da tela. Agora tem id (`memory-body`) e empilha no mobile.
  v0.6.24 — 18/10/2026: 🈯 TUI 100% em português (comandos, menus e frases de
            abertura) + 🌍 4 idiomas no mesmo plugin
            • Comandos barra da TUI em PT-BR/es/fr/zh: plugin de CLI
              `ufvai-pt` (37 comandos nativos traduzidos pelo keymap, mesmo
              `id` do nativo, `palette`/atalhos preservados) + comando
              `/idioma` com troca ao vivo; catálogo em
              `~/.config/opencode/tui/ufvai-pt/` (revisto no boot por
              `install_pt_plugin` + `merge_cli_plugins`).
            • Frases iniciais da tela de nova sessão: NÃO se faz patch no binário
              do motor (decisão de 18/10/2026). `pesquisai/tui_prompt.py` foi
              reduzido a `restore_if_needed()` — ele apenas restaura o original
              (`<binário>.orig-ufvai`) se uma versão anterior tiver alterado o
              bytecode, e remove o backup. Textos internos ("Ask anything…",
              exemplos da tela inicial, rótulos do rodapé) permanecem no idioma
              original do motor: literais do bytecode são compartilhados com
              contratos internos (renomear `commands` quebrava o SQLite com
              `table project has no column named comandos`).
            • Idioma resolvido por `tui_pt.detect_locale()`: `/idioma` (arquivo
              `ufvai-language.json`) → UFVAI_LANG/PESQUISAI_LOCALE → LANG →
              pt-BR; a troca no seletor da UI web (`/api/lang`) chama
              `launch_app._sync_terminal_locale()`, que grava o arquivo e só
              então reinicia o ttyd — terminal e interface no mesmo idioma.
            • Plugin `opencode-i18n-v2` REMOVIDO (duplicava comandos na paleta
              e trazia títulos em chinês): `strip_i18n_plugin()` +
              `cleanup_i18n_leftovers()`; removidos `pesquisai/opencode_i18n.py`
              e `pesquisai/assets/i18n/`.
            • 2 novos comandos de prompt em PT: `/iniciar` (≈ /init) e
              `/revisar-codigo` (≈ /review).
            • Testes novos: tests/test_comandos_pt.py,
              tests/test_prompt_restore.py e tests/test_sem_i18n.py.
  v0.6.23 — 17/10/2026: 🌐 i18n do TUI em PT-BR (plugin opencode-i18n-v2)
            • Locale pt-BR COMPLETO (190 comandos + grupos + 49 slash
              commands) implantado em ~/.config/opencode/i18n/locales/.
            • Detecção de idioma: PESQUISAI_LOCALE → língua do navegador
              (Accept-Language gravado pela UI web) → LANG/LC_ALL → pt-BR.
            • Novo módulo pesquisai/opencode_i18n.py (fail-open) + asset
              pesquisai/assets/i18n/pt-BR.json + testes dedicados.
            • Cadeia de boot: merge_opencode_config agora garante o plugin
              na lista `plugins`; apply_i18n implanta locale + estado.
  v0.6.22 — 15/10/2026: 🔒 exclusão efetiva dos agentes `build` e `plan`
            • Regra do autor: "exclua o build e o plan… tem que SEMPRE
              carregar o ufvai, inclusive na mensagem inicial do usuário
              novo".
            • `merge_agent_policy()` (opencode_config.py) grava em
              opencode.json: default_agent="UFVAI" + agents.build.disabled
              e agents.plan.disabled (mecanismo oficial da V2 — doc
              agents/#disabled).
            • `ensure_ufvai_agent()` adotou a política: qualquer
              (re)spawn do terminal (boot, start_ttyd, troca de idioma,
              troca de chave, /api/run_terminal, import de sessão)
              reafirma o UFVAI e mantém build/plan fora do catálogo e do
              fallback da V2.
            • Verificado em runtime: /api/agent sem build/plan após
              garantia; sessão nova criada com agent=UFVAI.
  v0.6.16 — 🐛 Fix retorno: heartbeat único apenas no clique "Continuar"
             • BUG v0.6.14: ao exibir "Bem-vindo de volta" o frontend disparava
               _heartbeat() imediato + setTimeout 2,5s + clique → 2-3 linhas
               "usuario_ativo" por retorno na planilha.
             • FIX: removidos os dois disparos automáticos; /api/access agora
               só é chamado no clique "Continuar". Guard _heartbeatSent impede
               duplo clique. Planilha registra exatamente 1 linha por retorno.
  v0.6.15 — 🐛 Prompt inicial respeita idioma detectado do sistema/navegador
            • BUG: _current_lang="pt_BR" fixo impedia _detect_system_lang() de
              rodar (truthy → nunca caía no `if not _current_lang`). ttyd
              sempre iniciava em pt_BR mesmo com LANG=en_US ou navegador em
              inglês. launch() chamava start_ttyd() ANTES de start_wrapper_server()
              que faria a detecção — ordem errada.
            • FIX backend `launch_app.py`: _current_lang inicia "" (vazio);
              novo helper _ensure_lang_initialized() (cookie file > PESQUISAI_LANG
              env > _detect_system_lang() > persiste) chamado em launch() ANTES
              do 1º ttyd e em start_wrapper_server() (idempotente). _build_ttyd_cmd
              agora cai em _detect_system_lang() quando _current_lang vazio.
              Normalização _LANG_MAP e _persist_lang garantidas.
            • FIX frontend `launch_app_responsive_v041.py`: window.load agora
              compara `GET /api/lang` (backend) com `getCurrentLang()` (navegador
              via navigator.language/cookie). Se divergir e LANGS válido, chama
              automaticamente `setLang(_currentLang)` uma vez por sessão
              (sessionStorage "ufvai_lang_synced") — corrige instalações antigas
              onde backend ficou preso em pt_BR.
  v0.6.14 — 🐛 Fix IP localhost + todo acesso logado na planilha
            • IP LOCALHOST FIX: _get_client_ip() agora aceita IP enviado pelo
              cliente (via JS ipify → POST /api/consent e /api/access) e o
              prefere quando for público — corrige Colab onde o proxy NÃO
              injeta X-Forwarded-For e o servidor via só 127.0.0.1. Fallback
              mantém headers (X-Forwarded-For, X-Real-IP etc.). Log de headers
              quando IP ainda é privado para diagnóstico.
            • TODO ACESSO NA PLANILHA: frontend agora busca IP público via
              https://api.ipify.org?format=json (CORS) no carregamento e o
              envia junto ao heartbeat; /api/access aceita {"ip": "..."} e
              registra flag "usuario_ativo" em TODO carregamento de usuário
              já registrado (antes só no clique "Continuar"). Backend também
              registra heartbeat automaticamente no GET /api/consent quando
              detecta revisita (perfil já aceito).
  v0.6.13 — 🐛 IP real do cliente + heartbeat "usuario_ativo" na revisita
            • IP: _get_client_ip() agora percorre a cadeia X-Forwarded-For
              da DIREITA para a esquerda, saltando IPs privados/loopback
              (127.0.0.1, 10.x, 172.16-31.x, 192.168.x) e devolve o
              primeiro IP PÚBLICO — no Colab o proxy do Google injeta o IP
              real do navegador; antes caía em client_address=127.0.0.1.
              Headers extra: X-Real-IP, CF-Connecting-IP, True-Client-IP,
              X-Forwarded, Forwarded (RFC 7239).
            • REVISITA: telemetry._read_profile() agora cai no backup
              persistente (Drive/~/PesquisAI backups/ufvai_consentimento.json)
              quando o ~/.config efêmero perdeu o e-mail — o heartbeat
              /api/access (flag "usuario_ativo") voltava SKIP e não gravava
              a revisita do usuário já registrado na planilha.
  v0.6.9 — 📜 Termos v2.1: telemetria opt-out + e-mail obrigatório +
            perfil persistente + botão Manual
            • TELEMETRIA OPT-OUT (LGPD art. 7º IX): caixa vem MARCADA
              (ativa por padrão), sem cookie _ga (analytics_storage
              'denied'); evento custom ufvai_session removido — canal
              client-side limitado ao page_view padrão; oposição a
              qualquer momento (art. 18 §2º) via caixa ou UFVAI_TELEMETRY=0.
            • E-MAIL DE ATIVAÇÃO OBRIGATÓRIO (art. 7º V): POST /api/consent
              devolve 400 sem e-mail válido; eliminação (art. 18) mantida.
            • PERFIL PERSISTENTE: backups/ufvai_consentimento.json (Colab:
              no Drive) guarda e-mail+SHA-256+preferências; GET /api/consent
              expõe profile → tela de Termos pré-preenchida e, se a mesma
              versão já foi aceita, pulada diretamente.
            • LOGS FORA DO DRIVE (Colab): ttyd.log → /tmp/ufvai-logs/;
              pasta logs/ do Drive não é mais criada.
            • BOTÃO 📘 MANUAL: rota /api/manual serve o MANUAL.md local
              (fallback GitHub); modal com Recarregar/Ver fonte; ícones
              distintos p/ Diretrizes (clipboard-list) e Manual (book-open);
              i18n manual.* nos 5 idiomas; tela de Termos responsiva
              (mobile/tablet, media queries ≤640px e landscape).
            • CORREÇÃO DebugView (bug v0.6.2): UFVAI_TELEMETRY_DEBUG agora
              envia "debug_mode":1 no params do evento (o antigo parâmetro
              de URL &debug_view=1 era ignorado pelo GA4).
            • Docs: TERMS_OF_USE v2.1 §7 (opt-out art. 7º IX + e-mail
              art. 7º V), PRIVACY.md, TELEMETRY.md §§4-5.
  v0.6.8 — 🧹 Painel único (zero prints) + LGPD reordenação + planilha de contatos
            • POLÍTICA PAINEL ÚNICO: em Colab todo feedback visual vem só do
              painel de boot (_BootPanel); prints verbosos suprimidos
              (launch_app/ttyd/jokes → logger.debug), warnings httplib2
              silenciados, drive.mount sem "Mounted at..." — painel é a única
              saída; offline mantém prints normais. progress_bar ASCII só offline.
            • LGPD: opcionais (estatísticas + e-mail) AGORA ANTES do
              "Li e aceito" — ordem: [ ] Opcional estatísticas → [ ] Opcional
              e-mail → [x] Li e aceito (obrigatório); vTerms 3 → 4.
            • Versão na tela de Termos corrigida: placeholder {__VERSION__} e
              variante __UFVAI_VERSION__ substituídos por 0.6.8; citação ABNT
              atualizada; favicon/proxy continua ok.
            • Planilha de contatos: criação automática via Drive/Sheets API
              (título "UFVAI — Contatos"), Apps Script Web App pronto
              (APPS_SCRIPT_PLANILHA_CONTATO.gs), endpoint injetado no painel
              Admin e em ufvai.env; fallback manual documentado.
  v0.6.7 — 🖼️ Tela de carregamento do Colab no tema da logomarca +
             ✉️ canal de contato opt-in configurável pela UI
            • BARRA DESDE O INÍCIO: um único painel leve no tema da
              logomarca (papel off-white, wordmark UFV navy + AI dourado)
              nasce na fase de clone do notebook e percorre TODA a
              inicialização (setup → launch) sem reiniciar; mensagens/
              checkpoints sempre ABAIXO da barra, percentual monotônico.
            • progress_bar.py aposentou a barra escura e virou driver do
              painel único (singleton get_boot_panel(), mesmo display_id);
              begin() idempotente; active() commita checkpoint pendente.
            • Botão final com a LOGO REAL (base64) no lugar do texto
              "✨ pronto"; badge verde separado removido no Colab;
              PesquisAI.ipynb rebrandizado (citação ABNT v0.6.7).
            • Canal de contato: URL HTTPS configurável no painel 📊
              Telemetria (Admin), salva em ~/.config/ufvai_telemetry.json;
              save_admin_config() parcial por campo; TELEMETRY.md §9.
  v0.6.6 — 🔐 Registro voluntário LGPD + Google Sheets (rebuild sobre 0.6.4)
            • registration.py: opt-in separado dos Termos, revogável
              (art. 18 VI), backup criptografado no Drive; webhook
              genérico UFVAI_REGISTRATION_URL (sem SMTP; PII nunca ao GA4).
            • scripts/google-apps-script/registration_webhook.gs + guia
              docs/REGISTRATION_SHEETS.md (+ token opcional).
            • Base = 0.6.4 estável (0.6.5 retirado por falha de splash/
              killpg/launcher); pytest 227/227.═
  v0.6.5 — 🔐 Terminal à prova de travamentos + splash de carregamento
            • KILL CIRÚRGICO: o ttyd é LÍDER do próprio grupo de processos
              (start_new_session=True) e fica rastreado em _TTYD_PROC —
              _stop_terminal() mata a árvore inteira (ttyd + bash + opencode)
              com um único killpg, sem o antigo pkill -f opencode global que
              matava o agente hospedeiro. Fallback determinístico:
              pkill -9 -x ttyd (COMM exato, nunca -f).
            • /api/ttyd_ready: o frontend faz polling antes de apontar o
              iframe — fim do ERR_CONNECTION_REFUSED exibido no boot, na
              troca de idioma e na restauração de sessão.
            • SPLASH DE CARREGAMENTO (boot-splash) na UI: logo UFVAI +
              status "Iniciando terminal…" e botão Recarregar nos 5 idiomas;
              timeout/falha com retorno honesto (sem reload às cegas).
            • _build_ttyd_cmd() extraído para retry determinístico;
              restart por idioma e restauração usam _ensure_terminal_ready()
              com retorno REAL (antes respondiam "ok" mesmo com a porta
              travada — causa do ERR_CONNECTION_REFUSED persistente).
  v0.6.4 — 🪪 Marca UFVAI completa · 🎨 Temas UFVAI no terminal · 🖼️ Logo oficial
            • AGENTS.md + agents/*.md (5 idiomas): agente agora se apresenta
              como UFVAI (IDs técnicos preservados: PESQUISAI_OBSIDIAN_VAULT,
              ~/PesquisAI, pacote pesquisai, tags pesquisai/*).
            • TEMAS DO TERMINAL (TUI): paleta harmonizada com a identidade
              UFVAI — escuro: fundos azul-noite #141c24/#1f2831, acento dourado
              #d4b56a/#b29149, amarelo UFV #D1A705; claro: papel quente + texto
              azul-escuro. Azul antigo #4fc3f7 eliminado.
            • Wrapper: fallback JS do applyWrapperTheme() alinhado ao CSS
              canônico (antes sobrescrevia com teal #157a73/#46a39b); tema
              claro dourado sobre papel; anti-flash #141c24; banner Colab em
              gradiente dourado.
            • LOGO OFICIAL na tela de Termos (assets/logo-oficial-288.jpg,
              servida por nova rota /assets/* offline-safe com whitelist e
              traversal guard). Modal de onboarding antigo do PesquisAI
              (welcome-hint) REMOVIDO — Termos é a única abertura.
            • Termos de Uso v2.0 (LGPD art. 7ºI/18, Portaria CNPq 2.664/2026,
              POSIC-UFV Res. Consu 12/2024, foro Viçosa/MG) + PRIVACY.md
              (direitos art. 18, DPO UFV, transferência internacional) +
              LICENSE com NOTICE de marca. Re-consentimento forçado
              (ufvai_terms_version=2).
            • TELEMETRY.md: guia do administrador em 8 passos (GA4 MP:
              propriedade → ID de medição → api_secret → ufvai.env/Colab →
              DebugView) + o que o admin vê × nunca vê + LGPD operacional.
            • install-offline.sh reescrito v0.6.4 (marca, portas 8001/8000,
              modelo config/ufvai.env, atalho ufvai).
  v0.6.3 — 🔌 Servidor persistente (offline) + 🎨 ícone UFVAI no dock
            • BUG CRÍTICO (offline): o wrapper HTTP roda em thread daemon —
              quando run() retornava, o interpretador encerrava e a porta
              8001 CAIA segundos após iniciar ("ERR_CONNECTION_REFUSED").
              No Colab não aparecia porque o kernel fica vivo.
              Fix: _offline_keep_alive() mantém o processo vivo fora do
              Colab (Ctrl+C / SIGTERM encerra; UFVAI_NO_KEEPALIVE=1 desliga).
            • REGRESSÃO restaurada: servidor dual-stack no loopback —
              Chromium/Firefox preferem ::1; sem listener IPv6 dava
              "conexão recusada" (padrão do 0.5.x).
            • Ícone: janela --app com WM_CLASS "UFVAI" agora casa com
              ufvai-app.desktop (StartupWMClass) + PNGs hicolor 256/128/64 —
              o dock mostra a lupa UFVAI em vez do ícone do Chromium.
  v0.6.2 — ⌨️ Terminal gravável + 🖥️ launcher app-mode + 📊 telemetria debug
            • BUG CRÍTICO (input): v0.6.0 perdeu a flag --writable do ttyd —
              o terminal ficava READ-ONLY ("não consigo digitar"). Restaurada
              em start_ttyd() e na restauração de sessão.
            • LAUNCHER (.deb): restaurado o comportamento do v0.5.1.10 que
              abria a UI como APP separado (Chrome --app/Chromium/Firefox/
              xdg-open) após esperar a porta 8001 responder (curl, até 180 s),
              com PID-file e reabertura se já estiver rodando.
            • TELEMETRIA: UFVAI_TELEMETRY_DEBUG=1 envia os eventos para o
              DebugView do GA4 (tempo real); launcher carrega
              ~/PesquisAI/config/ufvai.env (onde ficam UFVAI_GA_*).
  v0.6.1 — 🌐 Idioma do sistema + troca de idioma robusta + auto-open (offline)
            • BUG 1 (troca de idioma): o frontend recarregava a página em
              700ms enquanto o backend ainda reiniciava o ttyd (~3-4s) — a
              mensagem inicial não mudava de idioma. Agora setLang() é async,
              aguarda o POST /api/lang concluir e o backend só responde
              quando a porta do terminal já aceita conexões (_wait_port_open).
            • FEATURE 2: detecção do idioma do SISTEMA na 1ª execução
              ($LANGUAGE/$LC_ALL/$LC_MESSAGES/$LANG/locale) — saudação
              inicial no idioma do usuário; preferência fica persistida.
            • FEATURE 3 (offline/.deb): navegador abre AUTOMATICAMENTE
              quando a UI está pronta (thread + poll da porta; webbrowser
              com fallback xdg-open/open; UFVAI_NO_OPEN=1 desabilita).
            • REBRAND: banners Colab/console agora dizem "UFVAI pronto!" /
              "ABRIR O UFVAI".
  v0.5.1.8 — 🐛 3 bugfixes: provider buttons, session restore, backup confirm
            • BUG 1 (provider): JSON.stringify em onclick gerava SyntaxError
              em Python string tripla — trocado por data-provider +
              this.dataset.provider
            • BUG 2 (session history): "opencode session restore <id>"
              restaurava dados mas iniciava opencode do zero
              (linha 1600: ; {_opencode_bin}). Trocado para
              "opencode -s <id>" com no_fallback=true, + location.reload()
              para reconectar ao ttyd com a sessão correta.
            • FEATURE 3 (backup restore): pesquisaiConfirm() adicionado
              em doRestore(file) para confirmar antes de importar backup.
  v0.5.1.4 — 🧠 Editor de Memória Obsidian no botão 🧠
    v0.5.1.5 — 🔧 Botões não funcionavam (SyntaxError JS em string multilinha)
            • NOVO split view no overlay de Memória: lista de notas
              à esquerda + editor markdown com tabs Edit/Preview/Split
              à direita
            • 4 endpoints REST novos:
              GET  /api/obsidian/note?path=...     — ler nota crua
              GET  /api/obsidian/tree?subdir=...  — árvore agrupada
              GET  /api/obsidian/search?q=...     — busca BM25
              GET  /api/obsidian/tags             — tags com contagem
            • POST /api/obsidian/note (3 actions):
              action=save   — sobrescrever nota (force=true para humanas)
              action=create — criar nova nota de template
              action=delete — mover para .trash/ (force=true para humanas)
            • Buscar (debounce 150ms), editar com dirty indicator, salvar
              com confirmação, criar com diálogo de template, excluir
              com confirmação
            • Preview markdown via marked.js com destaque de [[wikilinks]]
              e #tags; estilo obsidian-like
            • 20 novas chaves i18n (memory.editor.*) em pt_BR, en_US,
              es_ES, fr_FR
            • Bugfix: from pathlib import Path (faltava — quebrava tree)
  v0.5.1.3 — 🔌 Conectores de Provedor de IA não salvavam (confirmProvider)
            • Bugfix: confirmProvider() crashava com TypeError antes de
              salvar a API key
            • Captura local de _selProv.id/env/name antes de closeProvider()
            • Verifica r.ok e d.ok no fetch (antes: sempre "✅ Salvo!")
            • closeProvider() movido para após sucesso
            • Não altera o array PROVIDERS (opencode_go/zen compartilham
              OPENCODE_API_KEY por design)
  v0.5.1.2 — 🧠 Botão Memória Obsidian no topbar
            • Overlay de Memória mostra status (ready/disabled/...) +
              stats (notas, tags, links) + notas recentes + daily notes
            • Endpoints: GET /api/obsidian (status)
  v0.5.1  — 🤖 Obsidian Autopilot (salvamento autônomo)
            • Módulo pesquisai.obsidian.autopilot (API de alto nível)
            • run_fast.py chama auto_init() na inicialização
            • Vault é CRIADO AUTOMATICAMENTE no Google Drive
            • Daily note e MOC raiz criados automaticamente
            • Sessão de log iniciada automaticamente
            • AGENTS.md injetado com instruções de salvamento autônomo
            • O agente SALVA SOZINHO — não espera o usuário pedir
            • API: recall(), save(), save_finding(), end_session()
  v0.5.0  — 🧠 Obsidian Second Brain (Long-Term Memory)
            • Módulo pesquisai.obsidian (8 arquivos, ~1.500 linhas)
            • Skill obsidian-memory (repositório git separado)
            • 10 templates Obsidian (daily, research, literature, ...)
            • Memória persistente entre sessões via vault no Google Drive
            • Busca BM25 offline + backlinks + wikilinks + tags
            • REGRA: vault SEMPRE no Google Drive (rejeita fora no Colab)
            • 71 testes pytest (100% passing) + teste e2e validado
            • Bugs corrigidos: update_note frozen + write_from_template dedup
  v0.4.0  — Release inicial com agente de pesquisa
  v0.4.1  — UI Fixes (Responsive + Theme + Language)
            • 6 media queries + hamburger menu
            • toggleTheme() recarrega iframe ttyd
            • Dropdown 4 idiomas (pt_BR, en_US, es_ES, fr_FR)
  v0.4.2  — Footer Responsive + Multilingual AGENTS.md
            • Rodapé 100% responsivo (flex-wrap + 2 linhas)
            • Modal de Diretrizes com AGENTS.md multilíngue
            • Endpoint GET /api/agents?lang=xx_XX
  v0.4.2.1 — Ses_10a4: 3 correções da sessão do usuário
            • Tema CLARO: contraste corrigido nos 6 modais
              (background:#181b1e fixo → variável CSS .modal-shell)
            • Dashboard de Saúde: openHealth() faz fetch em /api/health
              e popula a lista com badges de status
            • Modal de Diretrizes renderiza markdown (marked.js +
              github-markdown-css) ao invés de mostrar o .md como texto cru
  v0.4.2.3 — Ses_106b: 🔥 BUGFIX CRÍTICO — botões do wrapper não funcionavam
            • 🐛 JS BROKEN: a string tripla do launch_app_responsive_v041.py
              continha escapes de aspas que Python removia durante a compilação,
              gerando JavaScript com sintaxe inválida → TODOS os botões do HTML
              paravam de funcionar (erro SyntaxError no <script>)
            • ✅ renderSessions: trocado onclick inline (com escapes frágeis)
              por atributo data-session-id + event delegation (sem aspas dinâmicas)
            • ✅ restoreSession: trocado confirm com aspas escapadas por
              confirm(...chr(34)...) (concat JS, sem aspas escapadas)
            • ✅ escapeHtml: trocado object literal com aspas por if/else chain
              (evita conflito de aspas dentro do mapeamento)
            • ✅ Validado: Node.js --check passa, 79/79 testes pytest OK,
              10/10 funções JS verificadas
  v0.4.2.2 — Ses_10a4+: 6 correções adicionais (sessão do usuário)
            • 🖥️ FOOTER PC: botão provedor + "Powered by OpenCode"
              alinhados à direita no desktop (margin-left:auto)
            • 🧩 SKILLS: grant-finder e meta-search-br adicionados em
              skills/ com links para clonar do GitHub
            • 📜 SESSÕES: openSessions() agora faz fetch em /api/sessions
              e popula a lista (estava apenas abrindo o modal)
            • 🌍 LANG: ao trocar idioma, o ttyd é reiniciado com
              saudação no idioma + "(a partir de agora responda em X)"
              ao invés de "--prompt 'oi'" genérico
            • 📦 __version__.py movido para pesquisai/__version__.py
            • 🔄 v0.7.2 — RETOMADA DO AUTOSAVE SEM LOOP
              + CALENDÁRIO DO "RESTAURAR" CORRIGIDO
            • 🔄 LOOP DA RETOMADA: "Continuar de onde parei" fazia
              location.reload() -> a pagina recarregava -> a pergunta
              de retomada voltava -> o usuario clicava de novo -> LOOP.
              Agora a pergunta e OFERTADA UMA VEZ por aba do navegador
              (flag em sessionStorage, que sobrevive ao reload da mesma
              aba). O botao ↻ no rodape reoferece sob demanda.
            • 🗒️ CALENDÁRIO: dias com backup mostram a contagem,
              tooltip corrigido ("3 backups", nao "3)"), chips dos meses
              que TEM backup, item sem data nunca some do filtro e
              estado vazio oferece "Todas as datas".
            • 🧹 AGENTS.md: removido "- [link/lien/enlace]" das 4 variantes
"""

# ── Versão semântica (SemVer) ──────────────────────────────────
__version__: str = "0.7.11"
__brand__: str = "UFVAI"
__brand_tagline__: str = "Pesquisa científica com integridade."

# ── Metadados do release ───────────────────────────────────────
__release_date__: str = "2026-11-06"
__codename__: str = "VPN da UFV no Colab: OpenVPN em namespace isolado + tela de vínculo"

# ── Identidade do projeto ──────────────────────────────────────
__author__: str = "Gustavo Bastos Braga"
__author_email__: str = "gustavo.braga@ufv.br"
__institution__: str = "Universidade Federal de Viçosa (UFV)"
__registry__: str = "10356285004"
__repo_url__: str = "https://github.com/gustavobraga-byte/PesquisAI"
__license__: str = "MIT"

# ── Compatibilidade ────────────────────────────────────────────
__pesquisai_min_version__: str = "0.2.1"
__pesquisai_max_version__: str = "0.3.x"  # até próximo major

# ── Tema padrão ────────────────────────────────────────────────
__default_theme__: str = "pesquisai"  # 🌙 ESCURO (anti-flash CSS ativo)
__supported_themes__: list[str] = ["pesquisai", "pesquisai-light"]

# ── Componentes incluídos neste release ─────────────────────────
__components__: dict[str, str] = {
    "grant_finder": "0.1.0",
    "grant_finder_skill": "0.1.0",       # NOVO v0.4.2.2: link clonar
    "i18n": "0.2.0",
    "launch_app_responsive": "0.2.0",     # base responsiva
    "launch_app_responsive_v041": "0.1.0",  # drop-in patch v0.4.1
    "launch_app_responsive_v0421": "0.1.0",  # v0.4.2.1: 3 correções ses_10a4
    "launch_app_responsive_v0422": "0.1.0",  # NOVO v0.4.2.2: 6 correções ses_10a4+
    "launch_app_responsive_v0423": "0.1.0",  # NOVO v0.4.2.3: hotfix escapes JS
    "agents_multilingual": "0.1.0",
    "agents_modal": "0.1.0",              # modal de Diretrizes com markdown
    "footer_responsive": "0.1.0",         # footer com flex-wrap + 2 linhas
    "footer_pc_align": "0.1.0",           # NOVO v0.4.2.2: provedor + OpenCode à direita
    "sessions_loader": "0.1.0",           # NOVO v0.4.2.2: openSessions faz fetch
    "lang_aware_greeting": "0.1.0",       # NOVO v0.4.2.2: saudação no idioma
    "drive_guard": "0.7.7",               # NOVO v0.7.7: My Drive só em PesquisAI
    "vpn_ufv": "0.7.11",                  # NOVO v0.7.11: OpenVPN em namespace + SOCKS5
}

# ── Idiomas suportados ─────────────────────────────────────────
__supported_languages__: list[str] = ["pt_BR", "en_US", "es_ES", "fr_FR", "zh_CN"]

# ── Saudações iniciais por idioma (v0.4.2.2) ───────────────────
# Usadas pelo ttyd ao iniciar o terminal e ao trocar de idioma.
# Cada tupla = (saudação_curta, instrução_persistente, palavra "dica" no idioma)
# v0.4.2.2 (ajuste pós-ses_10a4+): removida a frase "Eu sou o PesquisAI" —
# a saudação agora é apenas a saudação curta + dica entre parênteses.
__language_greetings__: dict[str, tuple[str, str, str]] = {
    "zh_CN": (
        "你好！",
        "从现在开始请用简体中文回答。",
        "提示",
    ),
    "pt_BR": (
        "Olá!",
        "A partir de agora responda em português brasileiro.",
        "Dica",
    ),
    "en_US": (
        "Hello!",
        "From now on, please respond in English.",
        "Tip",
    ),
    "es_ES": (
        "¡Hola!",
        "A partir de ahora responda en español.",
        "Consejo",
    ),
    "fr_FR": (
        "Bonjour !",
        "À partir de maintenant, répondez en français.",
        "Astuce",
    ),
}

# ── Agências de fomento integradas ─────────────────────────────
__supported_grant_agencies__: list[str] = [
    # Brasil
    "CNPq", "CAPES", "FAPEMIG", "FAPESP", "FINEP",
    # Internacional
    "NIH", "NSF", "ERC", "Wellcome", "Horizon_Europe",
]

# ── Skills extras (v0.4.2.2) ────────────────────────────────────
__extra_skills__: list[dict[str, str]] = [
    {
        "id": "grant-finder",
        "name": "Grant Finder",
        "description": "Busca de editais de fomento em agências BR e internacionais.",
        "repo": "https://github.com/gustavobraga-byte/grant-finder",
        "local_path": "skills/grant-finder/",
    },
    {
        "id": "meta-search-br",
        "name": "Meta-Search BR",
        "description": "Busca unificada em 7 bases acadêmicas (PubMed, SciELO, LILACS, BDTD, OpenAlex, arXiv, bioRxiv).",
        "repo": "https://github.com/gustavobraga-byte/meta-search-br",
        "local_path": "skills/meta-search-br/",
    },
]

# ── Endpoints REST disponíveis ─────────────────────────────────
__api_endpoints__: list[str] = [
    "GET  /",                       # Wrapper HTML
    "GET  /api/sessions",           # Lista sessões
    "GET  /api/backups",            # Lista backups do Drive
    "GET  /api/health",             # Diagnóstico do sistema
    "GET  /api/theme",              # Tema atual
    "POST /api/theme",              # Persiste tema
    "GET  /api/diagnose",           # Diagnóstico completo
    "GET  /api/debug",              # Debug de chaves
    "GET  /api/apikey",             # Lista/máscara chaves
    "POST /api/apikey",             # Salva chave criptografada
    "POST /api/apikey/apply",       # Aplica chaves no env
    "POST /api/run_terminal",       # Executa comando no ttyd
    "POST /api/backup",             # Exporta sessão para Drive
    "POST /api/restore",            # Importa sessão do Drive
    "GET  /api/agents?lang=xx_XX",  # v0.4.2: serve AGENTS.md no idioma
    "POST /api/lang",               # NOVO v0.4.2.2: persiste idioma
    "GET  /api/lang",               # NOVO v0.4.2.2: lê idioma atual
    "GET  /api/obsidian",           # v0.5.1.2: status da memória
    "GET  /api/obsidian/note",      # NOVO v0.5.1.4: ler nota
    "GET  /api/obsidian/tree",      # NOVO v0.5.1.4: árvore de pastas
    "GET  /api/obsidian/search",    # NOVO v0.5.1.4: busca BM25
    "GET  /api/obsidian/tags",      # NOVO v0.5.1.4: lista de tags
    "POST /api/obsidian/note",      # NOVO v0.5.1.4: save/create/delete
    "GET  /api/vpn",                # NOVO v0.7.11: status da VPN da UFV
    "POST /api/vpn/connect",        # NOVO v0.7.11: conecta (CPF + senha)
    "POST /api/vpn/disconnect",     # NOVO v0.7.11: desconecta
    "POST /api/vpn/profile",        # NOVO v0.7.11: baixa/cola perfil .ovpn
    "POST /api/vpn/test",           # NOVO v0.7.11: testa acesso interno
    "POST /api/vpn/forget",         # NOVO v0.7.11: apaga credenciais
    "POST /api/vpn/answer",         # NOVO v0.7.11: resposta da tela inicial
]


def get_version() -> str:
    """Retorna a versão formatada para exibição."""
    return f"v{__version__} ({__codename__})"


def get_version_short() -> str:
    """Retorna apenas o número da versão."""
    return __version__


def get_greeting(lang: str = "pt_BR") -> str:
    """Retorna a saudação inicial do ttyd para o idioma solicitado.

    Formato: "{saudação_curta} ({dica}: {instrução_persistente})"
    Exemplo pt_BR: "Olá! (Dica: A partir de agora responda em português brasileiro.)"

    v0.4.2.2 (pós-ses_10a4+): a frase "Eu sou o PesquisAI" foi removida;
    agora a saudação é apenas a saudação curta + dica entre parênteses.
    """
    lang = (lang or "pt_BR").split("_")[0]
    full_lang = {"pt": "pt_BR", "en": "en_US", "es": "es_ES", "fr": "fr_FR", "zh": "zh_CN"}.get(lang, "pt_BR")
    greeting, persist, tip = __language_greetings__.get(
        full_lang, __language_greetings__["pt_BR"]
    )
    return f"{greeting} ({tip}: {persist})"


def get_full_metadata() -> dict[str, str]:
    """Retorna todos os metadados como dict (útil para logging/diagnóstico)."""
    return {
        "version": __version__,
        "release_date": __release_date__,
        "codename": __codename__,
        "author": __author__,
        "email": __author_email__,
        "institution": __institution__,
        "registry": __registry__,
        "license": __license__,
        "languages": ", ".join(__supported_languages__),
        "agencies": ", ".join(__supported_grant_agencies__),
        "extra_skills": ", ".join(s["id"] for s in __extra_skills__),
        "endpoints_count": len(__api_endpoints__),
    }
