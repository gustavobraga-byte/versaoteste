"""Módulo de traduções."""
